#ifndef COUNTINGSORT_H
#define COUNTINGSORT_H

#include <string.h>
#include "dataentry.h"

void CountingSort(DataEntry* array,int n, int maxValue);

#endif // COUNTINGSORT_H

