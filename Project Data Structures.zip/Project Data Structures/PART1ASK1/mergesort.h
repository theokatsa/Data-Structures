#ifndef MERGESORT_H
#define MERGESORT_H

#include <string.h>
#include "dataentry.h"

void MergeSort(DataEntry *arr, int low, int high);

#endif // MERGESORT_H

